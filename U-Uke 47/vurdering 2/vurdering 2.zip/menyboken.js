var menyboken={"navn":"Menyboken","versjon":"0.1",
    "filmer":[{"id":"1","tittel":"Pizza", "poster":"pizza.jpg","pris":119},
        {"id":"2","tittel":"Burger", "poster":"burger.jpg","pris":180},
        {"id":"3","tittel":"Spaghetti", "poster":"spaghetti.jpg","pris":219},
        {"id":"4","tittel":"Grilled Cheese", "poster":"grill.jpg","pris":89},
        {"id":"5","tittel":"Wagyu Beef", "poster":"waygu.jpg","pris":1899},
        {"id":"6","tittel":"Pepsi Max", "poster":"pepsi.jpg","pris":24},
        {"id":"7","tittel":"Vann", "poster":"vann.jpg","pris":20},
        {"id":"8","tittel":"Fanta", "poster":"fanta.jpg","pris": 26}
    ]
};